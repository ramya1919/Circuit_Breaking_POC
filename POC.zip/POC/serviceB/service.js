const express = require('express');
const app = express();

// Simulated function to fetch data (can be replaced with actual asynchronous operation)
const fetchData = async () => {
  const data = { name: 'BlueSpire' };
  const isError = false; 
  if (isError) {
    throw new Error('Service unavailable');
  }
  return data;
}; 

app.get('/api/data', async (req, res) => {
  try {
    const data = await fetchData(); 
   
    res.status(202).json(data); 
  } catch (error) {
    res.status(503).json({ error: error });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Service 1 is running on port ${PORT}`);
});
